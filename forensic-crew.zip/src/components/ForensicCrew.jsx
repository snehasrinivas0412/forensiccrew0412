import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { Fingerprint } from "lucide-react";

export default function ForensicCrew() {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.6 }}
        key={typeof window !== 'undefined' ? window.location.pathname : 'forensic'}
        className="scroll-smooth snap-y snap-mandatory h-screen overflow-y-scroll"
      >
        {/* Sticky Navbar */}
        <header className="sticky top-0 z-50 bg-black bg-opacity-80 backdrop-blur border-b border-pink-500">
          <nav className="flex items-center justify-between px-6 py-4 text-pink-300">
            <div className="flex items-center space-x-2 font-bold text-lg">
              <Fingerprint className="w-6 h-6 text-pink-400" />
              <span>Forensic Crew</span>
            </div>
            <div className="space-x-6">
              <a href="#case-studies" className="hover:text-pink-500 transition">Case Study Storytelling</a>
              <a href="#talks" className="hover:text-yellow-300 transition">Expert Talks</a>
              <a href="#workshops" className="hover:text-green-400 transition">Workshops</a>
              <a href="#contact" className="hover:text-white transition">Contact</a>
            </div>
          </nav>
        </header>

        <main className="relative min-h-screen bg-black text-white font-sans overflow-x-hidden">
          {/* Ambient Floating Particles - boom effect */}
          <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
            <div className="animate-pulse blur-2xl opacity-30 bg-gradient-to-tr from-pink-500 via-blue-500 to-green-500 w-[150%] h-[150%] rounded-full mx-auto" />
          </div>

          {/* Hero Section */}
          <section className="relative flex flex-col items-center justify-center text-center py-24 px-6 z-10 snap-start">
            <motion.h1
              className="text-6xl font-extrabold mb-4 drop-shadow-xl hover:scale-105 transition-transform"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
            >
              Forensic Crew
            </motion.h1>
            <motion.p
              className="text-xl text-pink-400 hover:text-pink-300"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.4 }}
            >
              Case Study Storytelling | Expert Talks | Workshops | Internships
            </motion.p>
          </section>

          {/* Forensic Tools Background Visual */}
          <div className="absolute top-0 left-0 w-full h-full opacity-10 z-0 bg-[url('/images/forensic-tools-bg.png')] bg-no-repeat bg-center bg-cover" />

          {/* Sections - Page 1 */}
          <section id="case-studies" className="grid grid-cols-1 md:grid-cols-3 gap-6 px-6 pb-20 z-10 snap-start">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              whileHover={{ scale: 1.05 }}
            >
              <Card className="bg-gradient-to-tr from-fuchsia-900 to-black border-pink-500 border shadow-xl hover:shadow-pink-500/50">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold text-pink-300 mb-2">Case Study Storytelling</h2>
                  <p>
                    Real-world forensic cases retold through in-depth narrative analysis and psychological insights.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.6 }}
              whileHover={{ scale: 1.05 }}
            >
              <Card id="talks" className="bg-gradient-to-tr from-yellow-900 to-black border-yellow-400 border shadow-xl hover:shadow-yellow-400/50">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold text-yellow-300 mb-2">Expert Talks</h2>
                  <p>
                    We bring you conversations with the brightest minds in forensic science and psychology. Real stories. Deep insights.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.9 }}
              whileHover={{ scale: 1.05 }}
            >
              <Card id="workshops" className="bg-gradient-to-tr from-green-900 to-black border-green-400 border shadow-xl hover:shadow-green-400/50">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold text-green-300 mb-2">Workshops & Internships</h2>
                  <p>
                    Hands-on sessions led by professionals to build real forensic skills. Apply what you learn from our talks.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </section>

          {/* Page 2 - Parallax & Depth */}
          <section className="bg-black text-white py-20 px-6 snap-start relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-[url('/images/depth-bg.jpg')] bg-cover bg-fixed opacity-10" />
            <div className="relative z-10">
              <h2 className="text-3xl font-bold text-center text-pink-400 mb-10">Behind the Scenes</h2>
              <p className="max-w-3xl mx-auto text-center text-gray-400 mb-10">
                Dive into how our case studies are built, how we research psychological profiles, and the digital forensic processes we use.
              </p>
              <div className="flex justify-center">
                <img
                  src="/images/behind-the-scenes.png"
                  alt="Behind the Scenes - Working Late"
                  className="rounded-xl shadow-lg max-w-md hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
          </section>

          {/* Page 3 - Gallery */}
          <section className="bg-black text-white py-20 px-6 snap-start">
            <h2 className="text-3xl font-bold text-center text-pink-400 mb-10">Forensic Glimpse</h2>
            <p className="max-w-3xl mx-auto text-center text-gray-400 mb-6">
              Explore images from our team’s late-night research, field sessions, and workshop moments.
            </p>
            <div className="flex justify-center">
              <img src="/images/user-dark.jpg" alt="Forensic Crew Founder at Work" className="rounded-xl shadow-lg max-w-sm hover:scale-105 transition-transform duration-500" />
            </div>
          </section>

          {/* Contact Section */}
          <section id="contact" className="bg-black border-t border-pink-500 py-10 text-center z-10">
            <h3 className="text-2xl font-semibold text-pink-400 mb-4">Contact Us</h3>
            <p className="mb-2">forensiccrew12@gmail.com</p>
            <Button variant="outline" className="border-pink-400 text-pink-300 hover:bg-pink-500 hover:text-black">
              Get in Touch
            </Button>
          </section>
        </main>
      </motion.div>
    </AnimatePresence>
  );
}
