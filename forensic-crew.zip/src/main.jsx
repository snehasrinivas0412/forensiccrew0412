import React from 'react';
import ReactDOM from 'react-dom/client';
import ForensicCrew from './components/ForensicCrew';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ForensicCrew />
  </React.StrictMode>
);
